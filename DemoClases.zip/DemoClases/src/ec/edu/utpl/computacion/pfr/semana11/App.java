package ec.edu.utpl.computacion.pfr.semana11;

import java.util.List;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;

public class App {
    public static void main(String[] args) throws InterruptedException {

        SubmissionPublisher<String> publisher= new SubmissionPublisher<>();
        //Crear subscriber
        PrinterSuscriber printerSuscriber=new PrinterSuscriber();
        //Suscribcion
        publisher.subscribe(printerSuscriber);
        List<String> items= List.of("1","x","2","1","x","2");
        //Enviar los datos a los suscriptores
        items.forEach(publisher::submit);
        Thread.sleep(1*10000);
        publisher.close();

    }
}
