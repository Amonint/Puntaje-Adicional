package ec.edu.utpl.computacion.pfr.semana11;

import java.util.List;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.Function;

public class App {
    public static void main(String[] args) throws InterruptedException {

        SubmissionPublisher<String> publisher= new SubmissionPublisher<>();
        //Crear subscriber
        PrinterSuscriber printerSuscriber=new PrinterSuscriber();
        //Funcion
        Function<String,String>toUpper= String::toUpperCase;
        //Crear processor
        TransformProcessor transformProcessor=new TransformProcessor(toUpper);
        //Suscribcion
        publisher.subscribe(transformProcessor);
        transformProcessor.subscribe(printerSuscriber);
        List<String> items= List.of("lupe","pedro","jose","peli","sexo","aa");
        //Enviar los datos a los suscriptores
        items.forEach(publisher::submit);
        Thread.sleep(1*1000);
        publisher.close();

    }
}
