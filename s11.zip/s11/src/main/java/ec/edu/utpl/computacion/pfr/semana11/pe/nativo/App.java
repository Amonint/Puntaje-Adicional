package ec.edu.utpl.computacion.pfr.semana11.pe.nativo;

import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.Function;
import java.util.function.Predicate;

public class App {
    public static void main(String[] args) throws InterruptedException {
        SubmissionPublisher<String> publisher = new SubmissionPublisher<>();

        //Crear el subscriber para imprimir
        PrinterSubscriber<Double> printerSubscriber = new PrinterSubscriber<>();

        //Función convertir de texto a número real
        Function<String,Double> toDouble = x->Double.valueOf(x.split(":")[1]);

        //Función filtrar texto que es número
        Predicate<Double> predicate = x->x>21.0;
        //Para mapear
        MapProcessor<String, Double> map2IntProcessor = new MapProcessor<>(toDouble);
        //Para filtrar
        FilterProcessor<Double, Double> onlyNumbersFilter = new FilterProcessor<>(predicate);

        //Flujo
        publisher.subscribe(map2IntProcessor);
        map2IntProcessor.subscribe(onlyNumbersFilter);
        onlyNumbersFilter.subscribe(printerSubscriber);

        List<String> items = List.of("TERM_1:22", "TERM_2:36", "TERM_3:19.7", "TERM_4:28.1", "TERM_5:22");
        //Enviar los datos a los suscritores
        items.forEach(publisher::submit);

        Thread.sleep(1 * 1000);

        publisher.close();
    }
}